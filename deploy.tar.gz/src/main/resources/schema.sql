CREATE TABLE IF NOT EXISTS study_reminder_task (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    plan_name VARCHAR(128) NOT NULL,
    plan_batch_id VARCHAR(64) NULL,
    study_date DATE NOT NULL,
    reminder_time TIME NOT NULL,
    trigger_time DATETIME NOT NULL,
    rag_topic VARCHAR(255) NOT NULL,
    study_content VARCHAR(1000) NULL,
    channels_json VARCHAR(255) NOT NULL,
    feishu_open_id VARCHAR(128) NULL,
    source_open_id VARCHAR(128) NULL,
    source_channel VARCHAR(32) NULL,
    source_msg_id VARCHAR(128) NULL,
    timezone VARCHAR(64) NOT NULL DEFAULT 'Asia/Shanghai',
    deleted_flag TINYINT NOT NULL DEFAULT 0,
    status TINYINT NOT NULL DEFAULT 1,
    sent_status TINYINT NOT NULL DEFAULT 0,
    error_message VARCHAR(1000) NULL,
    sent_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_trigger_status (trigger_time, status, sent_status, deleted_flag),
    INDEX idx_study_date (study_date),
    INDEX idx_source_open (source_open_id),
    INDEX idx_plan_batch (plan_batch_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE study_reminder_task CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

SET @ddl = (
    SELECT IF(
        EXISTS(
            SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'study_reminder_task'
              AND COLUMN_NAME = 'plan_batch_id'
        ),
        'SELECT 1',
        'ALTER TABLE study_reminder_task ADD COLUMN plan_batch_id VARCHAR(64) NULL'
    )
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @ddl = (
    SELECT IF(
        EXISTS(
            SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'study_reminder_task'
              AND COLUMN_NAME = 'source_open_id'
        ),
        'SELECT 1',
        'ALTER TABLE study_reminder_task ADD COLUMN source_open_id VARCHAR(128) NULL'
    )
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @ddl = (
    SELECT IF(
        EXISTS(
            SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'study_reminder_task'
              AND COLUMN_NAME = 'source_channel'
        ),
        'SELECT 1',
        'ALTER TABLE study_reminder_task ADD COLUMN source_channel VARCHAR(32) NULL'
    )
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @ddl = (
    SELECT IF(
        EXISTS(
            SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'study_reminder_task'
              AND COLUMN_NAME = 'source_msg_id'
        ),
        'SELECT 1',
        'ALTER TABLE study_reminder_task ADD COLUMN source_msg_id VARCHAR(128) NULL'
    )
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @ddl = (
    SELECT IF(
        EXISTS(
            SELECT 1
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'study_reminder_task'
              AND COLUMN_NAME = 'deleted_flag'
        ),
        'SELECT 1',
        'ALTER TABLE study_reminder_task ADD COLUMN deleted_flag TINYINT NOT NULL DEFAULT 0'
    )
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS feishu_event_log (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    event_id VARCHAR(128) NOT NULL,
    message_id VARCHAR(128) NULL,
    open_id VARCHAR(128) NULL,
    event_type VARCHAR(128) NULL,
    raw_body MEDIUMTEXT NULL,
    process_status TINYINT NOT NULL DEFAULT 0,
    error_message VARCHAR(1000) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_feishu_event_id (event_id),
    INDEX idx_feishu_process_status (process_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
