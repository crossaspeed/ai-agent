# docker-compose的学习
Dockerfile 只负责“怎么构建镜像”，而不负责“怎么把多个容器组合起来”以及“数据怎么持久化”
详细的参考代码：
- 这里的占位符通过根路径的.env文件进行替换

services:
  backend:
    build:
      context: .
      dockerfile: deploy/docker/backend.Dockerfile
    image: ai-agent-backend:latest
    restart: unless-stopped
    environment:
      SPRING_PROFILES_ACTIVE: prod
      SERVER_PORT: 8080
      MYSQL_HOST: mysql
      MYSQL_PORT: 3306
      MYSQL_DB: ai_agent
      MYSQL_USER: ai_agent
      MYSQL_PASSWORD: ${MYSQL_PASSWORD}
      MONGODB_URI: mongodb://mongodb:27017/chat_memory_db
      CHAT_MODEL_BASE_URL: ${CHAT_MODEL_BASE_URL:-https://api.deepseek.com}
      CHAT_MODEL_NAME: ${CHAT_MODEL_NAME:-deepseek-chat}
      DEEPSEEK_API_KEY: ${DEEPSEEK_API_KEY}
      EMBEDDING_BASE_URL: ${EMBEDDING_BASE_URL:-https://aihubmix.com/v1}
      EMBEDDING_API_KEY: ${EMBEDDING_API_KEY}
      PINECONE_API_KEY: ${PINECONE_API_KEY}
      PINECONE_INDEX_NAME: ${PINECONE_INDEX_NAME:-agent-index}
      FEISHU_APP_ID: ${FEISHU_APP_ID}
      FEISHU_APP_SECRET: ${FEISHU_APP_SECRET}
      FEISHU_BOT_OPEN_ID: ${FEISHU_BOT_OPEN_ID:-}
      FEISHU_CALLBACK_TOKEN: ${FEISHU_CALLBACK_TOKEN:-}
      FEISHU_LONG_CONNECTION_ENABLED: ${FEISHU_LONG_CONNECTION_ENABLED:-true}
      FEISHU_LONG_CONNECTION_WORKER_THREADS: ${FEISHU_LONG_CONNECTION_WORKER_THREADS:-2}
      SCHEDULER_REMINDER_FIXED_DELAY_MS: ${SCHEDULER_REMINDER_FIXED_DELAY_MS:-60000}
    depends_on:
      mysql:
        condition: service_healthy
      mongodb:
        condition: service_healthy
    networks:
      - ai-agent-net

  frontend:
    build:
      context: ./frontend
      dockerfile: ../deploy/docker/frontend.Dockerfile
    image: ai-agent-frontend:latest
    restart: unless-stopped
    environment:
      NODE_ENV: production
      BACKEND_INTERNAL_URL: http://backend:8080
    depends_on:
      backend:
        condition: service_started
    networks:
      - ai-agent-net

  nginx:
    image: nginx:1.27-alpine
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./deploy/nginx/default.conf:/etc/nginx/conf.d/default.conf:ro
      - ./deploy/certbot/www:/var/www/certbot:ro
      - /etc/letsencrypt:/etc/letsencrypt:ro
    depends_on:
      frontend:
        condition: service_started
      backend:
        condition: service_started
    networks:
      - ai-agent-net

  mysql:
    image: mysql:8.4
    restart: unless-stopped
    command:
      - --character-set-server=utf8mb4
      - --collation-server=utf8mb4_unicode_ci
    environment:
      MYSQL_DATABASE: ai_agent
      MYSQL_USER: ai_agent
      MYSQL_PASSWORD: ${MYSQL_PASSWORD}
      MYSQL_ROOT_PASSWORD: ${MYSQL_ROOT_PASSWORD}
      TZ: Asia/Shanghai
    volumes:
      - mysql_data:/var/lib/mysql
      - ./src/main/resources/schema.sql:/docker-entrypoint-initdb.d/01-schema.sql:ro
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost", "-uroot", "-p${MYSQL_ROOT_PASSWORD}"]
      interval: 10s
      timeout: 5s
      retries: 12
    networks:
      - ai-agent-net

  mongodb:
    image: mongo:7
    restart: unless-stopped
    volumes:
      - mongodb_data:/data/db
    healthcheck:
      test: ["CMD", "mongosh", "--eval", "db.adminCommand('ping')"]
      interval: 10s
      timeout: 5s
      retries: 12
    networks:
      - ai-agent-net

networks:
  ai-agent-net:
    driver: bridge

volumes:
  mysql_data:
  mongodb_data:
